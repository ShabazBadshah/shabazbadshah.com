# CSC301 Microservice Tutorial

__Date:__ Monday July 22, 2019

__School:__ University of Toronto

__Course:__ CSC301 - Software Engineering (Winter 2020)

---

This example will demonstrate communication between two RESTful microservices.
More specifically, the Index microservice will be calling the Add microservice to add two numbers provided by the Client.

## File Structure Overview

In this example there are two microservices:

### Services

1. __IndexServiceApplication.java__, the entry point from which other services will be called
2. __AddServiceApplication.java__, adds two numbers

---

## Requirements

1. Create a GET request in AddServiceApplication microservice that will return the last two numbers that were added together, and their answer. The endpoint for the GET request should be '/add'
2. Call the method created in step 1 from the IndexServiceApplication microservice via the '/addTwoNumbers' GET request
3. Return the response in a JSON format (see expected output below for exact format)

---

## HTTP POST, GET, PUT, DELETE Request Types

### POST

- Creates a resource on the server

#### Example

POST localhost:3000/course will create a course called CSC301 in the microservice (and may possibly store the info in a database) via the following data passed via a JSON body

```json
{
    "courseCode": "csc301",
    "numberStudents": "100",
    "examDate": "Jan 1, 9001",
    "instructor": "Ilir Dema"
}
```

---

### PUT

- Updates a resource on the server

#### Example

PUT localhost:3000/course/csc301 will update the csc301 course with the following data passed via a JSON body

```json
{
    "numberStudents": "100",
    "examDate": "Jan 1, 9001"
}
```

---

### GET

- Retrieves some data from a server via the URL

#### Example

GET localhost:3000/course/csc301 will grab all courses called csc301 from the server and may possibly return the following JSON data

```json
{
    "courseCode": "csc301",
    "numberStudents": "100",
    "examDate": "Jan 1, 9001",
    "instructor": "Ilir Dema",
    "lectureSection": "2",
    "courseTime": ["Thursdays @ 1PM", "Mondays @ 11AM"]
}
```

---

### DELETE

- Deletes a resource from the server

#### Example

DELETE localhost:3000/course/csc301 will delete the course called csc301 from the server. A possible response may look like the following

```json
{
    "courseDeletedSuccessfully": "yes",
    "courseDeleted": {
        "courseCode": "csc301",
        "numberStudents": "100",
        "examDate": "Jan 1, 9001",
        "instructor": "Ilir Dema",
        "lectureSection": "2",
        "courseTime": ["Thursdays @ 1PM", "Mondays @ 11AM"]
    }
}
```

For more information, please see this [article](https://www.restapitutorial.com/lessons/httpmethods.html)

---

## Questions

1. What microservice design pattern is being utilized?
2. How would you turn this microservice application into a monolithic application? What would be the different components?
3. If we modified the Add service implementation at some endpoint, would the Client have to make any changes to it's implementation/request?
4. Comment out the __AddServiceApplication__ file, what do you expect to happen? Will your Client query to Index break? Why or why not?

---

## Expected Output

If you send a PUT request to *localhost:3001/addTwoNumbers?firstNumber=3&secondNumber=9*, you should get the following response back

```json
{
"path": "GET http://localhost:3001/addTwoNumbers?firstNumber=3&secondNumber=9",
"data": {
    "path": "http://localhost:3002/add?firstNumber=3&secondNumber=9",
    "data": {
        "total": "12",
        "secondNumber": "9",
        "firstNumber": "3"
    },
    "message": "The last operation was: 3+9=12",
    "status": "OK"
}
```

---

## Setup

1. Clone repository
2. Import both AddServiceApplication and IndexServiceApplication projects
3. Right click each application file -> Run As -> Java Application
4. Make sure that both the Index and Add services are both running

---

## Usage

- Once you've started both services
- Utilize [Postman](https://www.getpostman.com/) to execute a request to a microservice

### Postman Usage

1. Type in the URL of the microservice resource that you want to request
    ![postman-1](./postman-1.png "Example of URL entered")
2. Select the type of request that you want to make (i.e. PUT, POST, GET, DELETE)
![postman-1](./postman-2.png "Type of request")
3. Put in the parameters (i.e. query or body parameters) that you want to pass to the microservice
![postman-1](./postman-3.png "Paramters being entered")
4. Hit "Send" and wait for result from microservice
![postman-1](./postman-4.png "Response from microservice")

## Lecture Slides

[Lecture Slides](https://docs.google.com/presentation/d/1eb_m_AevI4zwgmgoChvznOqXkZl8LmuUxOXXB2dmNx0/edit?usp=sharing)
