package com.csc301.tutorial.indexservice;

import java.io.IOException;
import java.net.ConnectException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@SpringBootApplication
public class IndexServiceApplication {

	// This service is running on PORT 3001
	public static void main(String[] args) {
		SpringApplication.run(IndexServiceApplication.class, args);
		System.out.println("Running Index Microservice");
	}
}

@RestController
@RequestMapping("/")
class IndexController {

	OkHttpClient client = new OkHttpClient();

	@RequestMapping(value = "/addTwoNumbers", method = RequestMethod.PUT)
	public @ResponseBody Map<String, Object> addTwoNumbers(@RequestParam("firstNumber") String firstNumber,
			@RequestParam("secondNumber") String secondNumber) {

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();
		
		String path = String.format("GET http://localhost:3001/addTwoNumbers?firstNumber=%s&secondNumber=%s", 
				firstNumber,
				secondNumber);

		try {
			if (Integer.valueOf(firstNumber) != null && Integer.valueOf(secondNumber) != null) {
				HttpUrl.Builder urlBuilder = HttpUrl.parse("http://localhost:3002" + "/add").newBuilder();
				urlBuilder.addQueryParameter("firstNumber", firstNumber);
				urlBuilder.addQueryParameter("secondNumber", secondNumber);
				String url = urlBuilder.build().toString();
				
				System.out.println(url);
			    RequestBody body = RequestBody.create(null, new byte[0]);

				Request request = new Request.Builder()
						.url(url)
						.method("PUT", body)
						.build();

				Call call = client.newCall(request);
				Response responseFromAddMs = null;

				String addServiceBody = "{}";

				try {
					responseFromAddMs = call.execute();
					addServiceBody = responseFromAddMs.body().string();
					response.put("data", mapper.readValue(addServiceBody, Map.class));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (NumberFormatException nfe) {
			response.put("message", "The numbers were not added correctly");

			Map<String, String> paramsProvided = new HashMap<String, String>();
			paramsProvided.put("firstNumber", String.valueOf(firstNumber));
			paramsProvided.put("secondNumber", String.valueOf(secondNumber));

			response.put("paramsProvided", paramsProvided);
			response.put("data", "{}");
			response.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		response.put("path", path);
		return response;
	}

	@RequestMapping(value = "/callToAddService", method = RequestMethod.GET)
	public @ResponseBody Map<String, Object> callToAddService() {

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();
		
		String path = "GET http://localhost:3002/callToAddService";

		Request request = new Request.Builder().url("http://localhost:3002" + "/add").method("GET", null).build();

		Call call = client.newCall(request);
		Response responseFromAddMs = null;

		String addServiceBody = "{}";

		try {
			responseFromAddMs = call.execute();
			addServiceBody = responseFromAddMs.body().string();
			response.put("data", mapper.readValue(addServiceBody, Map.class));
		} catch (IOException e) {
			e.printStackTrace();
		}

		response.put("path", path);
		return response;
	}
}
