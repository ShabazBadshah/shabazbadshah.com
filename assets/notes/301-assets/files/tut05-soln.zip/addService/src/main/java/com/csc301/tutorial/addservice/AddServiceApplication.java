package com.csc301.tutorial.addservice;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class AddServiceApplication {

	// This service is running on PORT 3002
	public static void main(String[] args) {
		SpringApplication.run(AddServiceApplication.class, args);
		System.out.println("Running Add Microservice");
	}
}

@RestController
@RequestMapping("/")
class AddController {

	int firstNumberAdded = Integer.MIN_VALUE;
	int secondNumberAdded = Integer.MIN_VALUE;
	int total = Integer.MIN_VALUE;

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<Map<String, Object>> getPreviousAddOperation() {
		
		Map<String, Object> dataPayload = new HashMap<String, Object>();
		
		String path = "http://localhost:3002/add";

		if (firstNumberAdded == Integer.MIN_VALUE || secondNumberAdded == Integer.MIN_VALUE
				|| total == Integer.MIN_VALUE) {

			dataPayload.put("message", "No add operations have been executed yet");
			dataPayload.put("data", "{}");
			dataPayload.put("status", HttpStatus.OK);

		} else {
			dataPayload.put("message",
					String.format("The last operation was: %d+%d=%d", firstNumberAdded, secondNumberAdded, total));

			Map<String, String> dataToReturn = new HashMap<String, String>();
			dataToReturn.put("firstNumberAdded", String.valueOf(firstNumberAdded));
			dataToReturn.put("secondNumberAdded", String.valueOf(firstNumberAdded));
			dataToReturn.put("total", String.valueOf(total));

			dataPayload.put("data", dataToReturn);
			dataPayload.put("status", HttpStatus.OK);
		}

		return ResponseEntity.status((HttpStatus) dataPayload.get("status")).contentType(MediaType.APPLICATION_JSON)
				.body(dataPayload);
	}

	@RequestMapping(value = "/add", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity<Map<String, Object>> addTwoNumbers(
			@RequestParam("firstNumber") String firstNumber, @RequestParam("secondNumber") String secondNumber) {

		Map<String, Object> dataPayload = new HashMap<String, Object>();

		String path = String.format("http://localhost:3002/add?firstNumber=%s&secondNumber=%s", 
				firstNumber,
				secondNumber);

		try {
			if (Integer.valueOf(firstNumber) != null && Integer.valueOf(secondNumber) != null) {
				this.firstNumberAdded = Integer.valueOf(firstNumber);
				this.secondNumberAdded = Integer.valueOf(secondNumber);
				this.total = this.firstNumberAdded + this.secondNumberAdded;

				dataPayload.put("message",
						String.format("The last operation was: %d+%d=%d", firstNumberAdded, secondNumberAdded, total));

				Map<String, String> dataToReturn = new HashMap<String, String>();
				dataToReturn.put("firstNumber", String.valueOf(this.firstNumberAdded));
				dataToReturn.put("secondNumber", String.valueOf(secondNumber));
				dataToReturn.put("total", String.valueOf(this.total));

				dataPayload.put("data", dataToReturn);
				dataPayload.put("status", HttpStatus.OK);
			}
		} catch (NumberFormatException nfe) {
			dataPayload.put("message", "The numbers were not added correctly");

			Map<String, String> paramsProvided = new HashMap<String, String>();
			paramsProvided.put("firstNumber", firstNumber);
			paramsProvided.put("secondNumber", secondNumber);

			dataPayload.put("paramsProvided", paramsProvided);
			dataPayload.put("data", "{}");
			dataPayload.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		dataPayload.put("path", path);

		return ResponseEntity.status((HttpStatus) dataPayload.get("status")).contentType(MediaType.APPLICATION_JSON)
				.body(dataPayload);
	}
}
